
import UserApi from '@api/user/user'
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'

//classes
const userApi = new UserApi();



//asynchoronous request 
export const fetchUserForDealerWithDepositedCash = createAsyncThunk(
  'dashboard/fetchUserWithDepositedCash',
  async (data: {  numRecords: string, page: number }) => {
    const response = await userApi.getDealerDepositedCash(data)

    return response.results
  },
)
export const fetchUserForDealerWithDepositedCredit = createAsyncThunk(
  'dashboard/fetchUserForDealerWithDepositedCredit',
  async (data: { numRecords: string, page: number }, { rejectWithValue }) => {
    try {
      const response = await userApi.getDealerDepositedCredit(data);
      if (response.message === 'Deposit Records') {
        return response.results;
      } else {
        return rejectWithValue('No data found');
      }
    } catch (error) {
      // Handle network errors or other errors here
      return rejectWithValue('Failed to fetch data');
    }
  }
);


//interfaces
export interface admin {
  depositedCredit: any;
  depositedCash: any;


}
// inital values
const initialState: admin = {
  depositedCredit: {docs:[],error:[]},
  depositedCash: {docs:[],error:[]},

}
//slices
export const adminSlice = createSlice({
  name: 'admin',
  initialState,
  reducers: {
    setDepositedCreditToInital: (state)=>{
      
    }
   
  },
  extraReducers: (builder) => {
    builder.addCase(fetchUserForDealerWithDepositedCash.fulfilled, (state, action) => {
      if (action.payload.docs.length > 0) {
        
        state.depositedCash = action.payload
      } else {
        state.depositedCash.error[0]={error:"No cash deposited to users"}
      }
    })
    builder.addCase(fetchUserForDealerWithDepositedCredit.fulfilled, (state, action) => {
      if (action.payload?.docs.length > 0) {
        state.depositedCredit = action.payload;
      } else {
        state.depositedCredit.error[0] = { error: "No credit deposited to users" };
      }
    })
  }
})


export const {  } = adminSlice.actions

export default adminSlice.reducer